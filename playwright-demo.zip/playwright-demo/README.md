# Playwright Demo Tests

Sample UI tests against https://www.saucedemo.com (a public practice site).

## Run locally
```bash
npm install
npx playwright install
npm test            # headless
npm run test:headed # see the browser
npm run report      # open HTML report
```

## CI
Tests run automatically on every push / PR to `main` via GitHub Actions
(`.github/workflows/playwright.yml`). The HTML report is uploaded as a build artifact.
